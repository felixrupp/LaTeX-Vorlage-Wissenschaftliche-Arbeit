public class HelloWorld {
	public String SayHello() {
		return "Hello World!";
	}
}
